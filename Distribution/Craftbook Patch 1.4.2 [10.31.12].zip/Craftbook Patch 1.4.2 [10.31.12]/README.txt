              <<<----====CRAFTBOOK PATCH====---->>>

Craftbook
---------

An incredibly lightweight python program built to
assist Minecraft users in remembering information
like identification numbers and crafting formulas
about in-game items and mobs.

Requirements
------------
>Windows XP/Vista/7/8
>Python 2.7 (If you have OS X or a Linux Distro)

How to use
----------

1) If you are on Windows, simply run the installer package
2) If you are on Linux or Apple, drag and drop the files into the directory with the Craftbook information in it.

Credits
-------

Suturesoft:
  Ben Schwabe
  Chris Gummin

If you have any questions or recommendations, please
email us at support@suturesoft.com and we'll try to get
back to you within a reasonable amount of time.

Disclaimer
----------

Copyright 2012 Suturesoft, all rights reserved.